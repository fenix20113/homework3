<?php
defined('_JEXEC') or die (deny access);
echo "hello;
?>




<script type="text/javascript">


	var clock = $('.registration').FlipClock(3600 * 24 * 3, {
		clockFace: 'DailyCounter',
		countdown: true
	});
</script>