<?php
defined('_JEXEC') or die(deny access);
echo "hello";
?>



